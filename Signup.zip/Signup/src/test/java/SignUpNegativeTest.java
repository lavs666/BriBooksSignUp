import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SignUpNegativeTest {
    public static void main(String[] args) {
        // Set the path for the ChromeDriver
        System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\iamtr\\\\Downloads\\\\chromedriver-win32\\\\chromedriver-win32\\\\chromedriver.exe");

        // Initialize WebDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to the signup page
        driver.get("https://www.bribooks.com/signup");

        // Maximize the browser window
        driver.manage().window().maximize();

        // Enter valid name
        WebElement nameField = driver.findElement(By.id("name"));
        nameField.sendKeys("John Doe");

        // Enter invalid email
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("invalid-email-format");

        // Enter valid mobile number
        WebElement mobileField = driver.findElement(By.id("mobile"));
        mobileField.sendKeys("9876543210");

        // Click on the 'Get OTP' button
        WebElement getOtpButton = driver.findElement(By.id("getOtpButton"));
        getOtpButton.click();

        // Validate that the appropriate error message is displayed for invalid email
        WebElement emailErrorMessage = driver.findElement(By.id("emailErrorMessage"));
        if (emailErrorMessage.isDisplayed()) {
            System.out.println("Invalid email detected! Test Passed.");
        } else {
            System.out.println("Error in email validation! Test Failed.");
        }

        // Close the browser
        driver.quit();
    }
}

