import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class BriBooks {
    public static void main(String[] args) {
        // Set the path for the ChromeDriver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\iamtr\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");

        // Initialize WebDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to the signup page
        driver.get("https://www.bribooks.com/signup");

        // Maximize the browser window
        driver.manage().window().maximize();

        // Initialize WebDriverWait
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Wait until the name field is visible, then enter a valid name
        WebElement nameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("formName")));
        nameField.sendKeys("kavya");

        // Wait until the email field is visible, then enter a valid email
        WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("formEmail")));
        emailField.sendKeys("kavya@example.com");

        // Wait until the mobile number field is visible, then enter a valid mobile number
        WebElement mobileField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"__next\"]/div/main/div[1]/div/div/div[2]/div/div[2]/div/div/form/div/div[3]/div/input")));
        mobileField.sendKeys("1112288911");

        // Wait until the 'Get OTP' button is clickable, then click it
        WebElement getOtpButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"__next\"]/div/main/div[1]/div/div/div[2]/div/div[2]/div/div/form/div/div[3]/button")));
        getOtpButton.click();

        // Wait until the OTP field is visible, then enter the received OTP (assuming it's 123456 for this test)
        WebElement otpField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("otp")));
        otpField.sendKeys("222210");

        // Wait until the radio button is clickable, then select it
        WebElement radioButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("yes")));
        radioButton.click();

        // Wait until the 'Sign Up' button is clickable, then click it
        WebElement signUpButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"__next\"]/div/main/div[1]/div/div/div[2]/div/div[2]/div/div/div[3]")));
        signUpButton.click();

        // Wait until the success message is visible, then validate that the signup was successful
        WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("successMessage")));
        if (successMessage.isDisplayed()) {
            System.out.println("Signup successful! Test Passed.");
        } else {
            System.out.println("Signup failed! Test Failed.");
        }

        // Close the browser
        driver.quit();
    }
}
