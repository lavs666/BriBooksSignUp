import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
//import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;


public class BriBooksTest {


        WebDriver driver;
        @BeforeClass
        public void setUpClass () {
            // Set up ChromeDriver (make sure the path to chromedriver.exe is correct)
            System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\Users\\\\\\\\iamtr\\\\\\\\Downloads\\\\\\\\chromedriver-win32\\\\\\\\chromedriver-win32\\\\\\\\chromedriver.exe");
        }
    @BeforeMethod
    public void setUpMethod() {

        driver = new ChromeDriver();
        //driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.get("https://www.bribooks.com/");
    }
    @Test
    public void navigationAndContentVerificationTest() {


        WebElement radioButton = driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[3]/button[2]"));
        radioButton.click();

        WebElement aboutEl = driver.findElement(By.partialLinkText("About Us"));
        aboutEl.click();
        WebElement ourstory = driver.findElement(By.partialLinkText("Our Story"));
        ourstory.click();
        WebElement BookstoreEl = driver.findElement(By.partialLinkText("Book Store"));
        BookstoreEl.click();
        String expectedTitle = "Books written by young authors for young readers";
        String actualTitle = driver.getTitle();
        if (expectedTitle.equals(actualTitle)) {
            System.out.println("Page title is correct: " + actualTitle);
        } else {
            System.out.println("Page title is incorrect. Expected: " + expectedTitle + ", but got: " + actualTitle);
        }
        WebElement ContactEl = driver.findElement(By.partialLinkText("Contact Us"));
        ContactEl.click();
    }
        @Test
        public void loginTest () {

            WebElement signinEl = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/main/div[1]/div/div/div[1]/div/button"));
            signinEl.click();
            // Enter valid name
            WebElement nameField = driver.findElement(By.id("formName"));
            nameField.sendKeys("kavya");

            // Enter valid email
            WebElement emailField = driver.findElement(By.id("formEmail"));
            emailField.sendKeys("kavya@example.com");

            // Enter valid mobile number
            WebElement mobileField = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/main/div[1]/div/div/div[2]/div/div[2]/div/div/form/div/div[3]/div/input"));
            mobileField.sendKeys("1112288911");
// Click on the 'Get OTP' button
            WebElement getOtpButton = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/main/div[1]/div/div/div[2]/div/div[2]/div/div/form/div/div[3]/button"));
            getOtpButton.click();

            // Wait for 20 seconds to receive the OTP
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

            // Enter the received OTP (assuming it's 123456 for this test)
            WebElement otpField = driver.findElement(By.id("otp"));
            otpField.sendKeys("222210");
            WebElement radioButtonEl = driver.findElement(By.id("yes"));
            radioButtonEl.click();

            // Click on the 'Sign Up' button
            WebElement signUpButton = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/main/div[1]/div/div/div[2]/div/div[2]/div/div/div[3]"));
            signUpButton.click();


        }
    @AfterMethod
    public void tearDownMethod() {
        // Close the browser after each test
        if (driver != null) {
            driver.quit();
        }
    }


}

