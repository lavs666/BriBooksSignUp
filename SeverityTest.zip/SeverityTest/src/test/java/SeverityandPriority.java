import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



public class SeverityandPriority {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Set up ChromeDriver (make sure the path to chromedriver.exe is correct)
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\iamtr\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.bribooks.com/");
    }

    @Test
    public void testLogoDistortion() {
        // Locate the logo element
        WebElement logo = driver.findElement(By.className("logo")); // Assuming the logo has an id 'logo'

        // Get the actual dimensions of the logo
        int logoWidth = logo.getSize().getWidth();
        int logoHeight = logo.getSize().getHeight();

        // Define the expected dimensions (based on known correct dimensions)
        int expectedWidth = 200; // Example value, replace with the actual expected width
        int expectedHeight = 100; // Example value, replace with the actual expected height

        // Check if the logo's dimensions are as expected
        Assert.assertEquals(logoWidth, expectedWidth, "Logo width is distorted!");
        Assert.assertEquals(logoHeight, expectedHeight, "Logo height is distorted!");
    }

    @AfterClass
    public void tearDown() {
        // Close the browser
        driver.quit();
    }


}
